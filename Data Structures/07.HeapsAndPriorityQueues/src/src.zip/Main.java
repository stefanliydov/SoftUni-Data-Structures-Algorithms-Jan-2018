public class Main {

    public static void main(String[] args) {
        BinaryHeap<Integer> bh = new BinaryHeap<>();
        bh.insert(1);
        bh.insert(6);
        bh.insert(2);
        bh.insert(9);
        bh.insert(10);
        bh.insert(3);
        String debug ="";
    }
}
