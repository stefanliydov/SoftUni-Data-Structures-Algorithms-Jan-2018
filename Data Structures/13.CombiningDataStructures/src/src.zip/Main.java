import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        PersonCollection collection = new PersonCollectionImpl();
        collection.addPerson("stefanlyudov@abv.bg","Stefan Lyudov",20,"Stara Zagora");

    }
}
