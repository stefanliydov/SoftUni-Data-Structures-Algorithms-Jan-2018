 class ConsoleWriter {
     static void writeLine(String message){
        System.out.println(message);
    }
}
